//normalisation
// const normalised = (original - minAsNumber) / (maxAsNumber - minAsNumber);

const t3 = tf.tensor1d([25, 76, 4, 23, -5, 22]);
const max = t3.max(); // 76
const min = t3.min(); 

const t5 = t3.sub(min).div(max.sub(min));

document.getElementById("output").innerText = t5;
  
  
  