function tensorLearning(){
    const xs = tf.tensor1d([1,2,3]);
    const ys = xs.mul(tf.scalar(5));
    document.getElementById("output").innerText = ys;
}

function tensor2dLearning(){
    // const xs = tf.tensor2d([[1,2,3],[4,5,6]]);
    const xs = tf.tensor2d([1,2,3,4,5,6],[2,3]);
    const ys = xs.mul(tf.scalar(5));
    document.getElementById("output").innerText = ys;
}


function tensor2dAddLearning(){
    const ys = tf.tensor1d([1,2,3]);
    const xs = tf.tensor2d([[1,2,3],[4,5,6]]);
    const zs = xs.add(ys);
    document.getElementById("output").innerText = zs;
}

function tensor2dSubLearning(){
    
    const ys = tf.tensor1d([1,2,3]);
    const xs = tf.tensor2d([[1,2,3],[4,5,6]]);
    const zs = ys.sub(xs);
    document.getElementById("output").innerText = zs;
}

//tensorLearning();
// tensor2dLearning();
// tensor2dAddLearning();
tensor2dSubLearning();