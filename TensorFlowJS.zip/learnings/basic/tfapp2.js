// y = mx+c
// y = 2+1 , 5*2+1, 10*2+1
function getYs(xs, m, c) {
  let m1 = tf.scalar(m);
  let c1 = tf.scalar(c);
  return m1.mul(xs).add(c1);
}
const t1 = tf.tensor1d([1,5,10]);
const t2 = getYs(t1, 2, 1);


document.getElementById("output").innerText = t2;


