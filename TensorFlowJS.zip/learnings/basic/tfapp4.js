for (let i = 0; i < 100; i++) {
   const x1= tf.tensor1d([1,2,3]);
   x1.print();
   x1.dispose();

}

tf.tidy(()=>{
    for (let i = 0; i < 100; i++) {
        tf.tensor1d([4,5,6]).print();
    }
})


console.log(tf.memory());

document.getElementById("output").innerText = 'Number of tensors in memory:'+ tf.memory().numTensors;