export const Utils = {
    updateLoaderText:function(msg){
        $(".loader-text").text(msg);
    },
    showLoader:function(){
        $("body").addClass("disable-screen");
        $(".loader-parent").show();
    },

    hideLoader:function(){
        $("body").removeClass("disable-screen");
        $(".loader-parent").hide();
    },

    plotData: function(data, featureName, predictedPointsArray=null){
        const values = [data.slice(0,1000)];
        const series = ["original"];
        if(Array.isArray(predictedPointsArray)){
            values.push(predictedPointsArray);
            series.push("predicted");
        }

        tfvis.render.scatterplot(
            {
                name:"Square Feet Vs House Price"
            },
            {
                values,
                series
            },
            {
                xLabel: featureName,
                yLabel: "Price"
            }
        );
    },


    

    // min max normalization
    normalise: function(tensorsData,previousMin=null,previousMax=null){
        const max = previousMax || tensorsData.max(); // 76
        const min = previousMin || tensorsData.min(); 
        return {
            tensor: tensorsData.sub(min).div(max.sub(min)),
            min,
            max
        }
    },


    deNormalise: function(tensor, min, max){
        return tensor.mul(max.sub(min)).add(min);
    }



}