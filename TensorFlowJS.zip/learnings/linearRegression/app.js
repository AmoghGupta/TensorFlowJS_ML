import { Utils } from "./utility/utils.js";

/** Linear Regression */
// linear  2variables x and y hence 2d data in tensors.
// y = mx + b
// Ax+By=C

const storageId = "ag-house-price-regression";
let normalisedFeatureTensor, normalisedLabelTensor;
let trainingFeatureTensor, trainingLabelTensor, testingFeatureTensor,testingLabelTensor;
let model, points;

async function run(){
    Utils.showLoader();

    //1. Import data from CSV
    const csvUrl = "http://127.0.0.1:8080/learnings/linearRegression/kc_house_data.csv";

    //2. extract X and Y values from imported data
    // importing this data into a tensorflow dataset object
    const csvDataset = tf.data.csv(csvUrl);
    // map is method provided in tensorflow dataset object
    const pointsDataSet = csvDataset.map((record)=>{
        return {
            "x": record.sqft_living,
            "y": record.price
        }
    });

    /*** 3.Converting tensorflow dataset array into JS array */
    // this is the dataset toArray method which returns a promise
    // now in points we have a normal JS array
    points = await pointsDataSet.toArray();
    Utils.updateLoaderText("Data Processed...");
    if(points.length%2 !=0){
        points.pop(); //remove one element if total records are odd
    }

     /*** 4.Shuffling the JS array, so that any kind of arrangement 
      * patterns in data are broken */
    //shuffling the points array data
    tf.util.shuffle(points);
    Utils.updateLoaderText("Data Shuffled...");


    //5. Plotting the extracted X and Y data
    // using tfjs-vis library to visualise the data
    Utils.updateLoaderText("Plotting data to Visualise...");
    Utils.plotData(points ,"Square Feet");
    Utils.updateLoaderText("Data plotting done..."); 
    
    Utils.updateLoaderText("Extracting tensors...");
    //6. Extracting feature tensor(inputs)
    const featureValues =  points.map(p=>p.x);
    const featureTensor = tf.tensor2d(featureValues, [featureValues.length, 1]);
    //7. Extracting label tensor(outputs)
    const labelValues =  points.map(p=>p.y);
    const labelTensor = tf.tensor2d(labelValues, [labelValues.length, 1]);

    // featureTensor.print();
    // labelTensor.print();
    
    Utils.updateLoaderText("Normalising tensors...");
    //8. Normalizing the extracted tensors (so that they lie in range 0-1)
    normalisedFeatureTensor = Utils.normalise(featureTensor);
    normalisedLabelTensor = Utils.normalise(labelTensor);
    //normalisedFeatureTensor.tensor.print();
    // normalisedLabelTensor.tensor.print();

    // //denormalizing the tensors to regain original tensor 
    // Utils.deNormalise(normalisedFeatureTensor.tensor,normalisedFeatureTensor.min, normalisedFeatureTensor.max).print();
    // Utils.deNormalise(normalisedLabelTensor.tensor,normalisedLabelTensor.min, normalisedLabelTensor.max).print();

    Utils.updateLoaderText("Splitting datasets for training and testing...");
    //9. Splitting datasets in two, one for training and one for testing
    [trainingFeatureTensor, testingFeatureTensor] = tf.split(normalisedFeatureTensor.tensor,2);
    [trainingLabelTensor, testingLabelTensor] = tf.split(normalisedLabelTensor.tensor,2);

    $("#model-status").text("Data loaded");
    $("#trainbutton").removeAttr("disabled");
    $("#load-model").removeAttr("disabled");
    Utils.hideLoader();
}

async function trainNewModel(){
    Utils.showLoader();
    Utils.updateLoaderText("Loading Model...");
    /************************************************/
    //CREATING, DEFINING, INSPECTING, COMPILING
    model = createModel();
    /*********INSPECTION OF A MODEL AND A LAYER */
    //inspecting a model
    model.summary();
    //vis model summary
    tfvis.show.modelSummary({name:"Model Summary"},model);
    // get layer 
    const layer = model.getLayer(undefined, 0);
    //vis layer information
    tfvis.show.layer({name:"Layer 1"}, layer);

    await createPredictionLine();
    /************************************************/

    /************************************************/
    // TRAINING AND VALIDATION
    
    // TRAINING IS AN ITERATIVE PROCESS
    // a. repeat for n epochs.
    // b. evaulate model against TRAINING data
    // c. evaluate uses loss function
    // d. optimizer updates model to minimize loss
    Utils.updateLoaderText("Training Model...");
    const result = await trainModel(model, trainingFeatureTensor,trainingLabelTensor);
    const trainingLoss = result.history.loss.pop();
    console.log(`Training set loss: ${trainingLoss}`);
     // VALIDATION IS FOR FREQUENT EVALUATION OF MODEL (IS LIKE A EXTRA SAFE GUARD)
    const validationLoss = result.history.val_loss.pop();
    console.log(`Validation set loss: ${validationLoss}`);
    
    $("#model-status").html(`Trained(unsaved). Training set loss: ${trainingLoss}`+`. Validation set loss: ${validationLoss}`);
    $("#test-model").removeAttr("disabled");
    $("#save-model").removeAttr("disabled");
    
    Utils.hideLoader();
}


async function createPredictionLine(){
    const [xs,ys] = tf.tidy(()=>{
        // linspace creates 100 equivalent points from 0-1 range
        const normalisedXs = tf.linspace(0,1,100);
        // providing input for 100 normalised xs tensors and getting output
        const normalisedYs = model.predict(normalisedXs.reshape([100,1]));
        //denormalising the normalisedXs and normalisedYs
        const xs = Utils.deNormalise(normalisedXs, normalisedFeatureTensor.min, normalisedFeatureTensor.max);
        const ys = Utils.deNormalise(normalisedYs, normalisedLabelTensor.min, normalisedLabelTensor.max);
        
        //dataSync Synchronously downloads the values from the tf.Tensor. 
        //This blocks the UI thread until the values are ready.
        return [xs.dataSync(), ys.dataSync()];
    });

    // generating x and y array points for plotting them
    const predictedPlots = Array.from(xs).map((val, index)=>{
        return {x:val, y:ys[index]}
    });
    await Utils.plotData(points,"Square feet",predictedPlots);
    
}

async function testModel(){
    Utils.showLoader();
    // TESTING IS NOT AN INTERACTIVE PROCESS
    // a. evaluate a model against TESTING data
    // b. find loss and compare against training loss
    // c. verify that model is well trained
    // d. guards against overfitting
    // e. ensures data was prepared properly
    Utils.updateLoaderText("Testing Model...");
    const lossTensor = model.evaluate(testingFeatureTensor, testingLabelTensor);
    const testingLoss = await lossTensor.dataSync();
    console.log(`Testing set loss: ${testingLoss}`);
    $("#model-test-status").text(`Testing set loss: ${testingLoss}`);
    Utils.hideLoader();
    $("#save-model").removeAttr("disabled");
    /************************************************/
}


function createModel(){
    //y = m(is weight/kernel)x + c(is bias) in terms of a neural n/w
    // we have 2 params i.e kernel and bias for a single unit (node)
    //hence for example so if we have 4 nodes that means 8 params

    // to represent linear model using layers api
    // single node, single input(x), a weight(m), a bias(c) and linear activation function 

    // defining a model
    const model = tf.sequential();
    //creating a layer
    // SINGLE LAYER, SINGLE NODE
    model.add(tf.layers.dense({
        units: 1, // no of nodes (single node mean 1)
        useBias: true, // (bias value )
        activation: 'linear',
        inputDim: 1 //number of features i.e input
    }));
    return compileModel(model);
}

function compileModel(model){
    // learning rate== 
    //1. if you decrease the learning rate too much then your model will train very slowly 
    //   and you will need to increase the number of epochs because it might not be able to train and minimize losses in less epochs..
    //2. if you increase the learning rate more then required then your model trains quickly but
    //   it will not be able to minimize losses.
    
    //   so its better to analyze, visualize the model while training and then tune this learning rate
    //   that suits your model the best

    // stochastic gradient descent technique
    // 0.1 is a learning rate set here
    const optimizer = tf.train.sgd(0.1);
    
     /********COMPILING A MODEL */
    Utils.updateLoaderText("Compiling Model...");
    model.compile({
        // calcuate loss
        loss: 'meanSquaredError', 
        optimizer: optimizer, 
        // OPTIMIZER updates model to minimize loss by adjusting params 
    });
    return model;
}


function trainModel(model, trainingFeatureTensor,trainingLabelTensor){
    // for visualizing our training performance
    // tf vis libary generates charts to visualize the performance
    const {onBatchEnd, onEpochEnd} = tfvis.show.fitCallbacks(
        {"name": "Training Performance"},
        ['loss']
    )
    return model.fit(trainingFeatureTensor,trainingLabelTensor, {
        batchSize: 32, // no. of inputs at a time, default is 32
        // increasing the batch size doesnt gurantee faster results as you might have to increase the
        // no. of epochs then, hence small batch size means less epochs, if more batch size then use more epochs
        epochs:20, // no. of training iterations
        callbacks:{
            // onEpochEnd: (epoch, log)=>console.log(`Epoch ${epoch}: loss = ${log.loss}`)
            onEpochEnd: onEpochEnd,
            // onBatchEnd:onBatchEnd,
            onEpochBegin: async function(){
                await createPredictionLine();
                const layer = model.getLayer(undefined, 0);
                tfvis.show.layer({name:"Layer 1"}, layer);
            }
        },
        validationSplit:0.2  //20% data will be used for validation purpose
    });
}


async function saveModel(){
    Utils.showLoader();
    Utils.updateLoaderText("Saving Model");
    const saveResults = await model.save(`localstorage://${storageId}`);
    document.getElementById("model-status").innerHTML=`Trained (saved) ${saveResults.modelArtifactsInfo.dateSaved}`;
    Utils.hideLoader();
    $("#load-model").removeAttr("disabled");
}

async function loadModel(){
    Utils.showLoader();
    Utils.updateLoaderText("Loading Model");
    const storageKey = `localstorage://${storageId}`;
    const models = await tf.io.listModels();
    const modelInfo = models[storageKey];
    if(modelInfo){
        $("#test-model").attr("disabled",true);
        model = await tf.loadLayersModel(storageKey);
        /*********INSPECTION OF A MODEL AND A LAYER */
        //inspecting a model
        model.summary();
        //vis model summary
        tfvis.show.modelSummary({name:"Model Summary"},model);
        // get layer 
        const layer = model.getLayer(undefined, 0);
        //vis layer information
        tfvis.show.layer({name:"Layer 1"}, layer);
        await createPredictionLine();

        document.getElementById("model-status").innerHTML=`Trained (saved) ${modelInfo.dateSaved}`;
        //$("#test-model").removeAttr("disabled");
        $("#predict-button").removeAttr("disabled");
    }else{
        alert("No pretrained/stored model found");
    }
    Utils.hideLoader();
}


function predict(){
    let inputValue = $("#sqft").val();
    const predictionInput = parseInt(inputValue);
    if(isNaN(predictionInput) || predictionInput < 100){
        alert("Provide valid values starting above 100 sqft");
        return;
    }
    tf.tidy(()=>{
        const inputTensor = tf.tensor1d([predictionInput]);
        const normalisedInput = Utils.normalise(inputTensor,normalisedFeatureTensor.min,normalisedFeatureTensor.max);
        const normalisedOutputTensor = model.predict(normalisedInput.tensor);
        const outputTensor = Utils.deNormalise(normalisedOutputTensor,normalisedLabelTensor.min,normalisedLabelTensor.max);
        const outputValue = outputTensor.dataSync()[0];
        document.getElementById("output").innerText= `${outputValue}$`;
    })
}

async function toggleVisor(){
    tfvis.visor().toggle();
}

run();

document.getElementById("test-model").addEventListener("click", testModel, false);
document.getElementById("predict-button").addEventListener("click", predict, false);
document.getElementById("load-model").addEventListener("click", loadModel, false);
document.getElementById("save-model").addEventListener("click", saveModel, false);
document.getElementById("trainbutton").addEventListener("click", trainNewModel, false);
document.getElementById ("visorToggle").addEventListener("click", toggleVisor, false);
